var firebaseConfig = {
  apiKey: "AIzaSyDUJWRYwMzejwaQ6b4KDqFiA0E2RzfhnDY",
  authDomain: "projeto-integrador-600a0.firebaseapp.com",
  databaseURL: "https://projeto-integrador-600a0.firebaseio.com",
  projectId: "projeto-integrador-600a0",
  storageBucket: "projeto-integrador-600a0.appspot.com",
  messagingSenderId: "1036140096889",
  appId: "1:1036140096889:web:a56105a43a256452df13a8",
};

firebase.initializeApp(firebaseConfig);
